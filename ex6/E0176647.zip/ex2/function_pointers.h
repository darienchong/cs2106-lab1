/*************************************
* Lab 1 Exercise 2
* Name: Darien Chong
* Student No: A0168214H
* Lab Group: 6
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern

#ifndef FUNCTION_POINTERS_H
#define FUNCTION_POINTERS_H

extern int (*func_list[5])(int);

void update_functions();

#endif
